INTERNAL_NAMES = [
    "camin_beton_rect",
    "capac_camin_beton_rect",
    "camin_rotund",
    "capac_camin_rotund",
    "spalier",
]
