export interface Client {
  id?: number;
  name?: string;
  address?: string;
  phone?: string;
  email?: string;
  bank?: string;
  iban?: string;
  cui?: string;
  reg?: string;
}
